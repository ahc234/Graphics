package ray;

public class TestFolderPath {
	private static String path = null;
	
	public static void set(String newPath)
	{
		path = newPath;
	}
	
	public static String get()
	{
		return path;
	}
}
