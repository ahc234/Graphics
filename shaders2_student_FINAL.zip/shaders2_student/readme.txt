Athena Cole ahc234
Kristin Murray kem226

No known problems with solution

Additional comments:

After completing the fire shader, we took a look at other methods that were out there for computing a similar effect! We referenced the tutorial below to create another version of the fire shader which can be viewed by specifying in the FireMaterial.java to use fireShader2.fs and fireShader2.vs.

http://www.clicktorelease.com/blog/vertex-displacement-noise-3d-webgl-glsl-three-js